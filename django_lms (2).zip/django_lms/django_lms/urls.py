from django.urls import path, include

urlpatterns = [
    path('', include('lms.urls', namespace='lms')),
]